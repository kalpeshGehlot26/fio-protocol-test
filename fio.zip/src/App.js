import React, { useState } from "react";
import Header from "./components/Header";
import Organisation from "./components/Organisation";
import SelectMode from "./components/SelectMode";
import BackArrow from "./assets/images/backArrow.svg";
import List from "./components/List";
import Final from "./components/Final";

const Screens = ({ currentScreen, ...rest }) => {
  const screenObj = {
    1: <SelectMode {...rest} />,
    2: <Organisation {...rest} />,
    3: <List {...rest} />,
    4: <Final {...rest} />,
  };

  if (screenObj[currentScreen]) {
    return screenObj[currentScreen];
  }
};

const App = () => {
  const [currentScreen, setCurrentScreen] = useState(1);

  return (
    <div className={` bg-transparent ${currentScreen === 4 ? "bg-image" : null}`}>
      <div className="container mx-auto">
        <Header />
        {currentScreen > 1 ? (
          <div
            className="ml-[115px] mt-8 z-10 relative"
            onClick={() => setCurrentScreen(currentScreen - 1)}
          >
            <img className="" src={BackArrow} />
          </div>
        ) : null}
        <div class="h-screen-minus-40 w-full grid place-items-center">
          <Screens
            currentScreen={currentScreen}
            setCurrentScreen={setCurrentScreen}
          />
        </div>
      </div>
    </div>
  );
};

export default App;
