import { useSpring, animated } from "@react-spring/web";
import React from "react";
import edit from "../assets/images/edit.svg";

const List = ({ setCurrentScreen }) => {

  const org = localStorage.getItem('org')

  const styles = useSpring({
    from: { transform: 'translateY(100px)', opacity: 0 },
    to: { transform: 'translateY(0px)', opacity: 1 },
    delay: 100,
    config: { tension: 220, friction: 80 }
  });

  const style1 = useSpring({
    from: { transform: 'translateY(100px)', opacity: 0 },
    to: { transform: 'translateY(0px)', opacity: 1 },
    delay: 600,
    config: { tension: 220, friction: 80 }
  });

  const style2 = useSpring({
    from: { transform: 'translateY(100px)', opacity: 0 },
    to: { transform: 'translateY(0px)', opacity: 1 },
    delay: 800, 
    config: { tension: 220, friction: 80 }
  });


  const style3 = useSpring({
    from: { transform: 'translateY(100px)', opacity: 0 },
    to: { transform: 'translateY(0px)', opacity: 1 },
    delay: 1000,
    config: { tension: 220, friction: 80 }
  });


  return (
    <div className="mt-40">
      <div className="flex justify-center space-y-8 items-center flex-col w-full font-Comfortaa">
        <div className="bg-gradient-to-l relative mx-auto mt-[-120px] rounded-lg from-[#DE08FD] to-[#0E22FE] flex justify-center items-center p-1 w-full ">
          <input
            placeholder="naga@metakeep.xyz"
            className="bg-[#050f42] placeholder:text-white text-center border-none focus:outline-none p-1 font-Comfortaa rounded-lg  text-white w-full text-[55px]"
          />
        </div>
        <div className="mx-auto text-center  mt-[70px] px-16 w-full">
          <animated.div style={styles} className="font-Comfortaa mx-auto mt-8 underline text-white">
            <span className="text-white text-[45px]">
              {`greatgammer@${org}`}
            </span>
            <img
              className="w-[50px] ml-4 inline mt-[-20px]"
              src={edit}
              onClick={() => setCurrentScreen(3)}
            />
          </animated.div>
          <animated.div style={style1} className="font-Comfortaa mx-auto mt-10 underline text-white">
            <span className="text-white text-[45px]">35djfbdk</span>
            <img
              className="w-[30px] mt-[-20px] ml-4 inline"
              src={edit}
              onClick={() => setCurrentScreen(3)}
            />
          </animated.div>
          <animated.div style={style2} className="font-Comfortaa mx-auto mt-4 underline text-white">
            <span className="text-white text-[45px]">438975jhk</span>
            <img
              className="w-[30px] mt-[-20px] ml-4 inline"
              src={edit}
              onClick={() => setCurrentScreen(3)}
            />
          </animated.div>
          <animated.div style={style3} className="font-Comfortaa mx-auto mt-4 underline text-white">
            <span className="text-white text-[45px]">4385vfgbrd</span>
            <img
              className="w-[30px] mt-[-20px] ml-4 inline"
              src={edit}
              onClick={() => setCurrentScreen(3)}
            />
          </animated.div>
        </div>

        <div>
          <button
            onClick={() => setCurrentScreen(4)}
            className="bg-gradient-to-l mt-[40px] rounded-lg from-[#DE08FD] to-[#0E22FE] text-white w-[300px] h-[80px] text-[55px]"
          >
            <span className="text-[55px] font-Comfortaa">Next</span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default List;
