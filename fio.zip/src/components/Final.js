import React, { useState, useEffect } from "react";
import { animated, useSpring } from "@react-spring/web";

const org = localStorage.getItem('org')

const variables = {
  orgName: org?.replace(/\s/g, ''),
};

const paragraphs = [
  { text: (vars) => `Registering domain name ${vars.orgName}..`, style: { color: 'white', fontSize: "30px" } },
  { text: (vars) => "Minting wallets for naga@metakeep.xyz...", style: { color: 'white', fontSize: "30px" } },
  { text: (vars) => "EVM",  style: { color: 'yellow', fontSize: "30px", fontWeight: "bold" } },
  { text: (vars) => "0xFDdfg435dfbdfvree...", style: { color: 'white', fontSize: "30px" } },
  { text: (vars) => "Sola...", style: { color: 'white', fontSize: "30px" } },
  { text: (vars) => `Registering domain name naga@${vars.orgName}.....`, style: { color: 'white', fontSize: "30px" } },
];

function TerminalLogs() {
  const [currentParagraphs, setCurrentParagraphs] = useState([]);
  const [currentCharIndex, setCurrentCharIndex] = useState(0);
  const [currentParagraphIndex, setCurrentParagraphIndex] = useState(0);

  const props = useSpring({
    from: { opacity: 0 },
    to: { opacity: 1 },
    delay: 50 * currentCharIndex,
  });

  useEffect(() => {
    const currentText = paragraphs[currentParagraphIndex]?.text(variables);
    if (currentParagraphIndex < paragraphs.length && currentText) {
      if (currentCharIndex < currentText.length) {
        setTimeout(() => {
          const updatedParagraphs = [...currentParagraphs];
          if (updatedParagraphs[currentParagraphIndex]) {
            updatedParagraphs[currentParagraphIndex].text += currentText[currentCharIndex];
          } else {
            updatedParagraphs[currentParagraphIndex] = { 
              text: currentText[currentCharIndex], 
              style: paragraphs[currentParagraphIndex].style 
            };
          }
          setCurrentParagraphs(updatedParagraphs);
          setCurrentCharIndex(currentCharIndex + 1);
        }, 50);
      } else {
        setCurrentCharIndex(0);
        setCurrentParagraphIndex(currentParagraphIndex + 1);
      }
    }
  }, [currentCharIndex, currentParagraphIndex, paragraphs, currentParagraphs, variables]);

  return (
    <div style={{  color: 'lime', padding: '10px' }} className="text-center">
      {currentParagraphs.map((paragraph, index) => (
        <animated.div key={index} style={index === currentParagraphIndex ? props : {}}>
          <span style={paragraph.style || {}}>{paragraph.text}</span>
          {index === currentParagraphIndex && <span>_</span>}
          <br />
        </animated.div>
      ))}
    </div>
  );
}

export default TerminalLogs;

