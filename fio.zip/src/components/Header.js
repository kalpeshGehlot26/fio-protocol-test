import React from "react";
import logo from "../assets/images/fiologo.png";

const Header = () => {
  return (
    <div className=" w-full">
      <div className="h-[120px] flex justify-between items-center">
        <div className="w-1/2">
          <img
            src={logo}
            className="my-[24px] w-[100px] ml-[120px]"
          />
        </div>
        <div className="w-1/2">
          <div className="text-white font-Comfortaa flex h-full w-full justify-center items-center space-x-14">
            <div className="text-[30px] text-black">About</div>
            <div className="text-[30px] text-black">Learn</div>
            <div className="text-[30px] text-black">Integrate</div>
            <div className="text-[30px] text-black">Community</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Header;
