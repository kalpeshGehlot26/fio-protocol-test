import React, { useState } from "react";
import OrgImage from "../assets/images/organisation.png";
import BackArrow from "../assets/images/backArrow.svg";

const Organisation = ({setCurrentScreen}) => {

  const [org, setOrg] = useState("")

  const handleSave = () => {
    setCurrentScreen(3)
    localStorage.setItem('org', org)
  }

  return (
    <div>
      <div className="flex justify-center space-y-8 items-center flex-col w-full font-Comfortaa">
        <img
          className="opacity-80 mt-[-100px] w-[80%] h-[80%]"
          src={OrgImage}
        />
      </div>
      <div className="mx-auto text-center mt-[70px] px-16">
        <div className="bg-gradient-to-l relative mx-auto rounded-lg from-[#DE08FD] to-[#0E22FE] flex justify-center items-center p-1 w-full ">
          <input
            placeholder="Enter organisation"
            onChange={(e) => setOrg(e.target.value)}
            className="bg-[#050f42] placeholder:text-white pr-20 pl-4 text-center border-none focus:outline-none p-1 font-Comfortaa rounded-lg  text-white w-full text-[55px]"
          />
          <img className="rotate-180 absolute right-3 w-[50px]" src={BackArrow} onClick={handleSave} />
        </div>
      </div>
    </div>
  );
};

export default Organisation;
